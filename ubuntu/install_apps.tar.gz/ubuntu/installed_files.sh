#!/bin/sh

echo "BROWSER/NETWORKING TOOLS"
echo "google-chrome, curl, nmap, net_tools, ifconfig"
echo

echo "SECURITY TOOLS"
echo "gpg2"
echo

echo "TEXT EDITORS"
echo "vs-code, neovim"
echo

echo 'PROGRAMMING LANGUAGES/FRAMWORKS'
echo "elixir, phoenix, ruby, python3, python"
echo


echo "VERSION MANAGERS"
echo "git, rvm, mix, hex"
echo

echo "DEVELOPER HAPPINESS"
echo "caffeine"
echo

echo "-----------------------------------PLEASE RUN-----------------------------------"
echo "NVM is stupid and doesn't do its job, so do this."
echo
echo "nvm install v10.15.2 && \\"
echo "nvm alias default v10.15.2 && \\"
echo "nvm use default v10.15.2 && \\"
echo "nvm use default"
echo
echo "------------------------------^^^^^PLEASE RUN^^^^^------------------------------"
echo


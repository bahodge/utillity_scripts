## Automate my life V1.0

What it does:
Automates installation of the following technologies

### Get Started

``

- BROWSER/NETWORKING TOOLS

  - google-chrome
  - curl
  - nmap
  - ifconfig
  - net_tools

- SECURITY TOOLS

  - gpg2

- TEXT EDITORS

  - vs-code
  - neovim

- PROGRAMMING LANGUAGES/FRAMWORKS

  - elixir
  - phoenix
  - ruby
  - python
  - python3

- VERSION MANAGERS

  - git
  - hex
  - mix
  - rvm

- DEVELOPER HAPPINESS
  - caffeine
